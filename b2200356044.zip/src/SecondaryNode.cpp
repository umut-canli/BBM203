//
// Created by umut on 23.12.2022.
//

#include "SecondaryNode.h"

SecondaryNode::SecondaryNode(string name,int data) : name(name),data(data) {
    left= nullptr;
    right= nullptr;
}
