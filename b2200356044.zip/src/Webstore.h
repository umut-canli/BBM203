
//
// Created by umut on 23.12.2022.
//

#ifndef ASSGN4_WEBSTORE_H
#define ASSGN4_WEBSTORE_H
#include "string"
#include "AVLTree.h"
#include "BinarySearchTree.h"
#include "RedBlackTree.h"
#include "ReadFile.h"
#include "sstream"
#include "vector"

using  namespace std;

class Webstore {
public:
    string file;
    void createWebStore(string inputName, string output1Name, string output2Name);


private:
};


#endif //ASSGN4_WEBSTORE_H
